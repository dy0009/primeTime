/*
 * COPYRIGHT 2003 Wolfgang Vahrson (mail@vahrson.de). ALL RIGHTS RESERVED.
 * 
 * Created on 21.08.2003
 *
 * $Header: /Users/wova/laufend/cvs/Utils/de/vahrson/util/Formatter.java,v 1.2 2003/10/02 07:31:22 wova Exp $
 */
package de.vahrson.util;

/**
 * @author wova
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public interface Formatter {
	public String format(Object o) throws Exception;

}
