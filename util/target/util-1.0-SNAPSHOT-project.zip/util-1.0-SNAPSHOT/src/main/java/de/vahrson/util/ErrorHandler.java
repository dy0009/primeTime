/*
 * Created on 10.04.2004
 *
 * $Header: /Users/wova/laufend/cvs/Utils/de/vahrson/util/ErrorHandler.java,v 1.2 2004/04/20 15:08:49 wova Exp $
 *  */
package de.vahrson.util;

/**
 * @author wova
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public interface ErrorHandler {
	public void handleError(Throwable problem);

}