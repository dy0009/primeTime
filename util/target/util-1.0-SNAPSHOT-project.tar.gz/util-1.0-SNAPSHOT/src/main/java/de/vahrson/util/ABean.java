package de.vahrson.util;

/**
 * Insert the type's description here.
 * Creation date: (12.03.2002 21:45:05)
 * @author: 
 */
public class ABean {
	String fA;
	int fB;
	Object fC; 
/**
 * ABean constructor comment.
 */
public ABean() {
	super();
}
/**
 * Insert the method's description here.
 * Creation date: (12.03.2002 21:46:24)
 * @return java.lang.String
 */
public java.lang.String getAFieldContent() {
	return fA;
}
/**
 * Insert the method's description here.
 * Creation date: (12.03.2002 21:46:24)
 * @return int
 */
public int getB() {
	return fB;
}
/**
 * Insert the method's description here.
 * Creation date: (12.03.2002 21:46:24)
 * @return java.lang.Object
 */
public java.lang.Object getC() {
	return fC;
}
/**
 * Insert the method's description here.
 * Creation date: (12.03.2002 21:46:24)
 * @param newA java.lang.String
 */
public void setAFieldContent(java.lang.String newA) {
	fA = newA;
}
/**
 * Insert the method's description here.
 * Creation date: (12.03.2002 21:46:24)
 * @param newB int
 */
public void setB(int newB) {
	fB = newB;
}
/**
 * Insert the method's description here.
 * Creation date: (12.03.2002 21:46:24)
 * @param newC java.lang.Object
 */
public void setC(java.lang.Object newC) {
	fC = newC;
}
}
