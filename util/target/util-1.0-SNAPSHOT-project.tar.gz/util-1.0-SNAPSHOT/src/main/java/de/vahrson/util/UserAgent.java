package de.vahrson.util;
/**
 * Insert the type's description here.
 * Creation date: (13.12.02 11:28:17)
 * @author: 
 */
public interface UserAgent {
	public final String PROPERTY_BROWSER="browser";
	public final String PROPERTY_BROWSER_VERSION="browserVersion";
	public final String PROPERTY_OS="oS";

	public final String BROWSER_IE="ie";
	public final String BROWSER_NS="ns";
	public final String BROWSER_OTHER="other";
	
	public final String BROWSER_VERSION_UNKNOWN="1";

	public final String OS_MAC="mac";
	public final String OS_WIN="win";
	public final String OS_OTHER="other";
	
}